export const COLORS = [
  {
    primaryColor: '#BA1EE9',
    secondaryColor: '#BA1EE920',
  },
  {
    primaryColor: '#ED1648',
    secondaryColor: '#ED164820',
  },
  {
    primaryColor: '#FCB50F',
    secondaryColor: '#FCB50F20',
  },
  {
    primaryColor: '#0DD579',
    secondaryColor: '#0DD57920',
  },
];
