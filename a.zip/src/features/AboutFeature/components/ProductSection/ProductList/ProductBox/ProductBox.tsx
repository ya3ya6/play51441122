import { Flex } from '@chakra-ui/react';
import { FunctionComponent } from 'react';

export const ProductBox: FunctionComponent = () => {
  return <Flex>Product Box</Flex>;
};
