import { Box } from '@chakra-ui/react';
import { useState } from 'react';

const Map = () => {
  const [map, setMap] = useState(null);

  return <Box />;
};

export default Map;
