export { default as HeroSection } from './HeroSection/HeroSection';
export { default as PostsSection } from './PostsSection/PostsSection';
