export const RelatedPostListData = [
  { id: 1, title: 'عوارض هایفوتراپی صورت', date: '4 آذر 1358' },
  { id: 2, title: 'آکنه چیست  ؟', date: '4 آذر 1358' },
  { id: 3, title: 'علامت کشیدگی پوست (استریا)', date: '4 آذر 1358' },
  { id: 4, title: 'اگزما پوستی چیست و درمان آن', date: '4 آذر 1358' },
];
