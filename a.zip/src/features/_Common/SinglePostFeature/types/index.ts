export * from './GetCommentType';
