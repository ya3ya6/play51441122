export { BottomDetailsBoxSection } from './BottomDetailsBoxSection/BottomDetailsBoxSection';
export { FaqSection } from './FaqSection/FaqSection';
export { GetCommentSection } from './GetCommentSection/GetCommentSection';
export { RelatedPostsSection } from './RelatedPostsSection/RelatedPostsSection';
export { StudyGuideSection } from './StudyGuideSection/StudyGuideSection';
export { TopDetailsBoxSection } from './TopDetailsBoxSection/TopDetailsBoxSection';
export { SetCommentSection } from './SetCommentSection/SetCommentSection';
export { ContentSection } from './ContentSection/ContentSection';
