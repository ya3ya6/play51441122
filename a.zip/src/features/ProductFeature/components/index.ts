export { default as VideoSection } from './VideoSection/VideoSection';
export { default as HeroSection } from './HeroSection/HeroSection';
export { default as DetailsSection } from './DetailsSection/DetailsSection';
export { default as ContentSection } from './ContentSection/ContentSection';
export { default as CommentSection } from './CommentSection/CommentSection';
