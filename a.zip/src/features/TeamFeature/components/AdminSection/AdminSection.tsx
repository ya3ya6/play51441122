import { Flex } from '@chakra-ui/react';
import { FunctionComponent } from 'react';

interface AdminSectionProps {}

const AdminSection: FunctionComponent<AdminSectionProps> = () => {
  return <Flex />;
};

export default AdminSection;
