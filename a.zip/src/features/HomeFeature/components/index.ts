export { OurNewsSection } from './OurNewsSection/OurNewsSection';
export { OurProductsSection } from './OurProductsSection/OurProductsSection';
export { StatisticsList } from './StatisticsList/StatisticsList';
export { AboutSection } from './AboutSection/AboutSection';
export { CommentSection } from './CommentSection/CommentSection';
export { LatestArticleSection } from './LatestArticleSection/LatestArticleSection';
export { VideoSection } from './VideoSection/VideoSection';
