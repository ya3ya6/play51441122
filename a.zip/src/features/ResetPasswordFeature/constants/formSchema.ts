export const FormSchema = [
  {
    id: 'email',
    label: 'form.email',
    placeHolder: 'youremail@gmail.com',
    type: 'email',
  },
];
