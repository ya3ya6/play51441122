export type PostGetSeoTagsListAPIArgsType = {
  url: string;
};

export type PostGetSeoTagsListAPIResponseType = {
  id: number;
  url_regex: string;
  html_code: string;
}[];
