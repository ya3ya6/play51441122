export type GetMagHeaderPostsAPIAxiosResponse = {
  id: number;
  title: string;
  description: string;
  cover: string;
  cover_alt: string;
  url: string;
  language: string;
  color: string;
}[];
