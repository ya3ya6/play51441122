export interface PostNewsLetterAPIArgsType {
  email: string;
}
