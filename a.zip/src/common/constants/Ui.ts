export const COLORS = {
  gray100: '#edf2f7',
  primaryColor: '#2d85a5',
};
