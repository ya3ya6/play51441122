export type CountryAppType = 'AE' | 'IR' | 'TR' | 'CN' | 'EN';
