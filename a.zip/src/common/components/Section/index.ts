export { NewsSection } from './NewsSection/NewsSection';
export { VideosSection } from './NewsVideosSection/VideosSection';
export { SubCategoriesSection } from './SubCategoriesSection/SubCategoriesSection';
export { ArticlesSection } from './ArticlesSection/ArticlesSection';
export { WebinarSection } from './WebinarSection/WebinarSection';
export { TutorialVideosSection } from './TutorialVideosSection/TutorialVideosSection';
export { MagViewedSection } from './MagViewedSection/MagViewedSection';
export { LatestNewsSection } from './LatestNewsSection/LatestNewsSection';
