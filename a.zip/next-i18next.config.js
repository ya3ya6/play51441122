module.exports = {
  i18n: {
    locales: ['fa', 'en', 'zh', 'ar', 'tr'],
    defaultLocale: 'fa',
    localeDetection: false,
  },
  reloadOnPrerender: true,
};
